from controller import Supervisor, Keyboard
import time

class SevenSegmentController:
    def __init__(self, supervisor, color_on, color_off):
        self.supervisor = supervisor
        self.digit_segments = [
            ["seven_segment_a1", "seven_segment_b1", "seven_segment_c1", "seven_segment_d1", "seven_segment_e1", "seven_segment_f1", "seven_segment_g1"],
            ["seven_segment_a2", "seven_segment_b2", "seven_segment_c2", "seven_segment_d2", "seven_segment_e2", "seven_segment_f2", "seven_segment_g2"],
            ["seven_segment_a3", "seven_segment_b3", "seven_segment_c3", "seven_segment_d3", "seven_segment_e3", "seven_segment_f3", "seven_segment_g3"]
        ]

        self.segment_patterns = {
            0: [1,1,1,1,1,1,0],
            1: [0,1,1,0,0,0,0],
            2: [1,1,0,1,1,0,1],
            3: [1,1,1,1,0,0,1],
            4: [0,1,1,0,0,1,1],
            5: [1,0,1,1,0,1,1],
            6: [1,0,1,1,1,1,1],
            7: [1,1,1,0,0,0,0],
            8: [1,1,1,1,1,1,1],
            9: [1,1,1,1,0,1,1]
        }

        self.color_on = color_on
        self.color_off = color_off

        self.segment_nodes = []
        for digit in self.digit_segments:
            digit_fields = []
            for segment_def in digit:
                shape_node = self.supervisor.getFromDef(segment_def)
                if shape_node is None:
                    print(f"Error: Node with DEF name '{segment_def}' not found!")
                    exit()

                appearance_field = shape_node.getField("appearance")
                if appearance_field is None:
                    print(f"Error: 'appearance' field not found in node '{segment_def}'!")
                    exit()

                appearance_node = appearance_field.getSFNode()
                if appearance_node is None:
                    print(f"Error: appearance node is None in '{segment_def}'!")
                    exit()

                material_field = appearance_node.getField("material")
                if material_field is None:
                    print(f"Error: 'material' field not found in appearance node of '{segment_def}'!")
                    exit()

                material_node = material_field.getSFNode()
                if material_node is None:
                    print(f"Error: material node is None in '{segment_def}'!")
                    exit()

                diffuse_color_field = material_node.getField("diffuseColor")
                if diffuse_color_field is None:
                    print(f"Error: 'diffuseColor' field not found in material node of '{segment_def}'!")
                    exit()

                digit_fields.append(diffuse_color_field)
            self.segment_nodes.append(digit_fields)

    def set_digit(self, digit_index, value):
        pattern = self.segment_patterns[value]
        for i, state in enumerate(pattern):
            color = self.color_on if state else self.color_off
            self.segment_nodes[digit_index][i].setSFVec3f(color)

    def display_number(self, number):
        if not (0 <= number <= 999):
            print("Error: Number out of range (0-999)")
            return
        hundreds = number // 100
        tens = (number % 100) // 10
        units = number % 10

        self.set_digit(2, hundreds)
        self.set_digit(1, tens)
        self.set_digit(0, units)

if __name__ == "__main__":
    supervisor = Supervisor()
    timestep = int(supervisor.getBasicTimeStep())

    keyboard = Keyboard()
    keyboard.enable(timestep)

    color_on = [0, 1, 0]  # 綠色亮燈
    color_off = [0, 0, 0]  # 黑色關燈

    controller = SevenSegmentController(supervisor, color_on, color_off)

    numbers_to_show = [18, 22, 31, 36]
    index = 0
    controller.display_number(numbers_to_show[index])

    last_switch_time = 0
    debounce_delay = 0.3  # 秒數，可自行調整切換速度

    while supervisor.step(timestep) != -1:
        key = keyboard.getKey()
        current_time = time.time()

        if key == Keyboard.DOWN and current_time - last_switch_time > debounce_delay:
            index = (index + 1) % len(numbers_to_show)
            controller.display_number(numbers_to_show[index])
            last_switch_time = current_time

        elif key == Keyboard.UP and current_time - last_switch_time > debounce_delay:
            index = (index - 1) % len(numbers_to_show)
            controller.display_number(numbers_to_show[index])
            last_switch_time = current_time
